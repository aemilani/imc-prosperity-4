import jsonpickle
import numpy as np
from dataclasses import dataclass
from datamodel import OrderDepth, TradingState, Order
from typing import List


@dataclass
class Product:
    name: str
    limit: int
    fair_value: float = None
    position: int = 0
    posted_buy_volume: int = 0
    posted_sell_volume: int = 0
    best_bid: float = None
    best_ask: float = None
    best_bid_size: int = None
    best_ask_size: int = None


@dataclass
class Emeralds(Product):
    name: str = 'EMERALDS'
    limit: int = 80
    fair_value: float = 10000


@dataclass
class Tomatoes(Product):
    name: str = 'TOMATOES'
    limit: int = 80
    volume_thr: int = 15


def trade_emeralds(emeralds: Emeralds) -> List[Order]:
    orders: List[Order] = []

    # Market making
    buy_quantity = emeralds.limit - emeralds.position
    if buy_quantity > 0:
        orders.append(Order(emeralds.name, 9992, buy_quantity))  # Buy order

    sell_quantity = emeralds.limit + emeralds.position
    if sell_quantity > 0:
        orders.append(Order(emeralds.name, 10008, -sell_quantity))  # Sell order

    return orders


class Trader:
    def run(self, state: TradingState):
        conversions = 0

        result = {}
        for product_name in state.order_depths:
            position = state.position.get(product_name, 0)
            print(f'{product_name} position: {position}')
            orders: List[Order] = []
            if product_name == 'EMERALDS':
                product = Emeralds(position=position)
                orders.extend(trade_emeralds(product))

        trader_data = ""
        return result, conversions, trader_data